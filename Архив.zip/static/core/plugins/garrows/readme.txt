GArrows for krpano

Please visit http://www.robostitcher.com/Garrows-krpano
